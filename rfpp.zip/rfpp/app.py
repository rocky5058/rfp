import re
import base64
import logging
import time
import os.path
import json
import mysql.connector
import shutil
import sys
from googleapiclient.discovery import build
from google_auth_oauthlib.flow import InstalledAppFlow
from google.oauth2.credentials import Credentials
from google.auth.transport.requests import Request
from googleapiclient.errors import HttpError
from googleapiclient.http import BatchHttpRequest
from tabulate import tabulate
from datetime import datetime, timedelta
from typing import Dict, List, Tuple
import pytz
from dateutil.parser import parse as parse_date
import email
from functools import wraps
from flask import Flask, render_template, request, redirect, url_for, session, flash

# Configure logging with both file and console output
logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('date_parsing.log'),
        logging.StreamHandler(sys.stdout)
    ]
)
logging.getLogger('google_auth_oauthlib').setLevel(logging.DEBUG)

# Flask app setup
app = Flask(__name__)
app.secret_key = '8f2a9b7c3e6d1f4a8c9e2b5d7f0a3e1c'
logging.debug("Flask app initialized")

SCOPES = [
    'https://www.googleapis.com/auth/gmail.readonly',
    'https://www.googleapis.com/auth/calendar.readonly'
]

# Load MySQL configuration from mysql.json
def load_mysql_config(file_path='mysql.json') -> dict:
    """Load MySQL configuration from a JSON file."""
    try:
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"MySQL configuration file '{file_path}' not found.")
        with open(file_path, 'r') as f:
            config = json.load(f)
        required_keys = ['host', 'user', 'password', 'database']
        missing_keys = [key for key in required_keys if key not in config]
        if missing_keys:
            raise KeyError(f"Missing required keys in {file_path}: {', '.join(missing_keys)}")
        logging.info(f"Successfully loaded MySQL configuration from {file_path}")
        return config
    except (FileNotFoundError, json.JSONDecodeError, KeyError) as e:
        logging.error(f"Failed to load MySQL configuration: {e}")
        raise

MYSQL_CONFIG = load_mysql_config()

def clean_old_backups(backup_dir='backups', max_age_days=30):
    """Delete token backups older than max_age_days."""
    try:
        if not os.path.exists(backup_dir):
            return
        now = datetime.now(pytz.UTC)
        for filename in os.listdir(backup_dir):
            file_path = os.path.join(backup_dir, filename)
            if os.path.isfile(file_path):
                mtime = datetime.fromtimestamp(os.path.getmtime(file_path), tz=pytz.UTC)
                if (now - mtime).days > max_age_days:
                    os.remove(file_path)
                    logging.info(f"Deleted old backup: {file_path}")
    except Exception as e:
        logging.error(f"Failed to clean old backups: {e}")

def backup_token(token_path='token.json'):
    """Create a timestamped backup of token.json before deletion."""
    if not os.path.exists(token_path):
        return
    try:
        backup_dir = 'backups'
        os.makedirs(backup_dir, exist_ok=True)
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        backup_path = os.path.join(backup_dir, f'token_backup_{timestamp}.json')
        shutil.copy(token_path, backup_path)
        logging.info(f"Backed up {token_path} to {backup_path}")
    except Exception as e:
        logging.error(f"Failed to backup {token_path}: {e}")

def init_database():
    """Initialize MySQL database and create necessary tables."""
    try:
        conn = mysql.connector.connect(**MYSQL_CONFIG)
        cursor = conn.cursor()
        # Table for storing opportunities
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS opportunities (
                id INT AUTO_INCREMENT PRIMARY KEY,
                email_id VARCHAR(255) UNIQUE,
                subject TEXT,
                online_link TEXT,
                event_date TEXT,
                agency TEXT,
                reference TEXT,
                contact TEXT,
                raw_subject TEXT,
                extraction_error TEXT,
                processed_at TIMESTAMP
            )
        ''')
        # Table for tracking processed email IDs
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS processed_emails (
                email_id VARCHAR(255) PRIMARY KEY,
                processed_at TIMESTAMP
            )
        ''')
        # Table for users
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                username VARCHAR(255) PRIMARY KEY,
                password VARCHAR(255) NOT NULL,
                is_admin BOOLEAN DEFAULT FALSE
            )
        ''')
        # Insert master user if not exists
        cursor.execute('''
            INSERT IGNORE INTO users (username, password, is_admin)
            VALUES (%s, %s, %s)
        ''', ('admin', 'Lucifer@723', True))
        conn.commit()
        logging.info("MySQL database initialized successfully.")
    except mysql.connector.Error as e:
        logging.error(f"Failed to initialize MySQL database: {e}")
        raise
    finally:
        if conn.is_connected():
            cursor.close()
            conn.close()

def get_db_connection():
    """Create and return a MySQL database connection."""
    try:
        conn = mysql.connector.connect(**MYSQL_CONFIG)
        return conn
    except mysql.connector.Error as e:
        logging.error(f"Failed to connect to MySQL: {e}")
        raise

def retry_on_transient_error(max_attempts=3, backoff_factor=1):
    """Decorator to retry on transient HttpError with exponential backoff."""
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            attempts = 0
            while attempts < max_attempts:
                try:
                    return func(*args, **kwargs)
                except HttpError as e:
                    transient_codes = {429, 500, 502, 503, 504}
                    if e.resp.status not in transient_codes:
                        raise
                    attempts += 1
                    if attempts == max_attempts:
                        raise
                    sleep_time = backoff_factor * (2 ** (attempts - 1))
                    logging.warning(f"Transient error {e.resp.status} in {func.__name__}, retrying in {sleep_time}s (attempt {attempts}/{max_attempts})")
                    time.sleep(sleep_time)
        return wrapper
    return decorator

@retry_on_transient_error()
def authenticate_google() -> tuple[build, build]:
    """
    Authenticates Gmail and Calendar APIs using token-based credentials.
    Ensures a refresh token is issued and enforces a 6-month validity by tracking creation time.
    """
    creds = None
    token_path = 'token.json'
    token_creation_time = None
    six_months = timedelta(days=183)

    clean_old_backups()

    if os.path.exists(token_path):
        try:
            with open(token_path, 'r') as token_file:
                token_data = json.load(token_file)
            creds = Credentials.from_authorized_user_info(token_data, SCOPES)
            token_creation_time = token_data.get('creation_time')
            logging.info(f"Loaded credentials from {token_path}. Refresh token present: {creds.refresh_token is not None}")
        except (ValueError, json.JSONDecodeError) as e:
            logging.error(f"Failed to load credentials from {token_path}: {e}")
            backup_token(token_path)
            os.remove(token_path)
            creds = None
            token_creation_time = None

    if token_creation_time:
        try:
            creation_dt = datetime.fromisoformat(token_creation_time)
            current_dt = datetime.now(pytz.UTC)
            if current_dt - creation_dt > six_months:
                logging.info(f"Token is older than 6 months (created: {token_creation_time}). Forcing re-authentication.")
                backup_token(token_path)
                os.remove(token_path)
                creds = None
        except ValueError as e:
            logging.error(f"Invalid creation_time in {token_path}: {e}. Deleting and re-authenticating...")
            backup_token(token_path)
            os.remove(token_path)
            creds = None

    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            try:
                creds.refresh(Request())
                logging.info("Successfully refreshed access token.")
            except Exception as e:
                logging.error(f"Failed to refresh token: {e}")
                if os.path.exists(token_path):
                    backup_token(token_path)
                    os.remove(token_path)
                creds = None

        if not creds:
            try:
                flow = InstalledAppFlow.from_client_secrets_file('client.json', SCOPES)
                creds = flow.run_local_server(
                    port=8080,
                    access_type='offline',
                    prompt='consent'
                )
                logging.info(f"OAuth flow completed. Refresh token obtained: {creds.refresh_token is not None}")
            except FileNotFoundError:
                logging.error("client.json file not found")
                raise
            except Exception as e:
                logging.error(f"OAuth flow failed: {e}")
                raise

        if creds:
            try:
                token_data = json.loads(creds.to_json())
                token_data['creation_time'] = datetime.now(pytz.UTC).isoformat()
                with open(token_path, 'w') as token:
                    json.dump(token_data, token, indent=2)
                logging.info(f"Saved credentials to {token_path}. Refresh token: {creds.refresh_token is not None}, Creation time: {token_data['creation_time']}")
            except Exception as e:
                logging.error(f"Failed to save credentials to {token_path}: {e}")
        else:
            logging.error("No valid credentials obtained from OAuth flow")
            raise ValueError("Authentication failed: No valid credentials obtained.")

    try:
        gmail_service = build('gmail', 'v1', credentials=creds)
        calendar_service = build('calendar', 'v3', credentials=creds)
        return gmail_service, calendar_service
    except Exception as e:
        logging.error(f"Failed to build API services: {e}")
        raise

def get_processed_email_ids() -> set:
    """Retrieve set of processed email IDs from the MySQL database."""
    conn = get_db_connection()
    try:
        cursor = conn.cursor()
        cursor.execute('SELECT email_id FROM processed_emails')
        processed_ids = {row[0] for row in cursor.fetchall()}
        return processed_ids
    except mysql.connector.Error as e:
        logging.error(f"Failed to fetch processed email IDs: {e}")
        raise
    finally:
        cursor.close()
        conn.close()

def save_opportunities(opportunities: List[Dict], email_ids: List[str]):
    """Save opportunities and processed email IDs to the MySQL database."""
    conn = get_db_connection()
    try:
        cursor = conn.cursor()
        current_time = datetime.now(pytz.UTC).strftime('%Y-%m-%d %H:%M:%S')

        for opp, email_id in zip(opportunities, email_ids):
            cursor.execute('''
                INSERT INTO opportunities (
                    email_id, subject, online_link, event_date, agency, reference, contact,
                    raw_subject, extraction_error, processed_at
                ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                ON DUPLICATE KEY UPDATE
                    subject = VALUES(subject),
                    online_link = VALUES(online_link),
                    event_date = VALUES(event_date),
                    agency = VALUES(agency),
                    reference = VALUES(reference),
                    contact = VALUES(contact),
                    raw_subject = VALUES(raw_subject),
                    extraction_error = VALUES(extraction_error),
                    processed_at = VALUES(processed_at)
            ''', (
                email_id,
                opp['subject'],
                opp['online_link'],
                opp['event_date'],
                opp['agency'],
                opp['reference'],
                opp['contact'],
                opp['raw_subject'],
                opp['extraction_error'],
                current_time
            ))
            cursor.execute('''
                INSERT IGNORE INTO processed_emails (email_id, processed_at)
                VALUES (%s, %s)
            ''', (email_id, current_time))

        conn.commit()
        logging.info(f"Saved {len(opportunities)} opportunities to MySQL database")
    except mysql.connector.Error as e:
        logging.error(f"Failed to save opportunities to MySQL: {e}")
        raise
    finally:
        cursor.close()
        conn.close()

def deduplicate_events(events: List[Dict], unparsed_events: List[Dict]) -> List[Dict]:
    """Removes duplicate events based on subject, URL, reference, and due date."""
    seen = set()
    deduplicated_events = []
    for event in events:
        url = event.get('online_link', 'NOT AVAILABLE').lower().strip('.,;:!?')
        reference = event.get('reference', 'NOT AVAILABLE').upper()
        due_date = event.get('event_date', 'NOT AVAILABLE')
        subject = event.get('subject', 'NOT AVAILABLE').lower().strip()
        subject = re.sub(r'\s+', ' ', subject).strip('.,;:!?')
        dedup_key = (subject, url, reference, due_date)
        if dedup_key in seen:
            event_copy = event.copy()
            event_copy['reason'] = f"Duplicate entry (same subject: {subject}, URL: {url}, reference: {reference}, due date: {due_date})"
            unparsed_events.append(event_copy)
            continue
        seen.add(dedup_key)
        deduplicated_events.append(event)
    return deduplicated_events

def list_all_emails(gmail_service: build, calendar_service: build) -> Dict:
    """Fetches and processes new emails, stores results, and returns data for display."""
    try:
        google_service_count = 0
        daily_bids_count = 0
        api_error_count = 0
        dedup_skip_count = 0
        data_skip_count = 0

        processed_ids = get_processed_email_ids()
        messages = []
        next_page_token = None

        one_year_ago = datetime.now(pytz.UTC) - timedelta(days=365)
        query = f"after:{one_year_ago.strftime('%Y/%m/%d')}"
        logging.info(f"Fetching emails with query: {query}")

        @retry_on_transient_error()
        def fetch_messages(page_token):
            return gmail_service.users().messages().list(
                userId='me',
                maxResults=1000,
                pageToken=page_token,
                q=query
            ).execute()

        while True:
            try:
                result = fetch_messages(next_page_token)
                new_messages = [msg for msg in result.get('messages', []) if msg['id'] not in processed_ids]
                messages.extend(new_messages)
                next_page_token = result.get('nextPageToken')
                logging.info(f"Fetched {len(result.get('messages', []))} messages, {len(new_messages)} new. Next page token: {next_page_token}")
                if not next_page_token:
                    break
            except HttpError as e:
                if e.resp.status == 403:
                    logging.error(f"Quota exceeded: {e}")
                    return {"error": "Gmail API quota exceeded. Try again later or increase quota in Google Cloud Console."}
                raise

        opportunities = []
        message_data_dict = {}
        batch_requests = 0
        seen_link_ref_pairs = set()
        seen_opportunities = set()
        email_ids = [msg['id'] for msg in messages]

        def batch_callback(request_id, response, exception):
            nonlocal api_error_count
            if exception is not None:
                api_error_count += 1
                message_data_dict[request_id] = {
                    'error': f"Batch request error: {str(exception)}"
                }
            else:
                message_data_dict[request_id] = response

        def execute_batch_with_retry(batch, max_attempts=3, backoff_factor=1):
            attempts = 0
            while attempts < max_attempts:
                try:
                    batch.execute()
                    return
                except HttpError as e:
                    if e.resp.status != 429:
                        raise
                    attempts += 1
                    if attempts == max_attempts:
                        raise
                    sleep_time = backoff_factor * (2 ** (attempts - 1))
                    logging.warning(f"Rate limit error in batch execution, retrying in {sleep_time}s (attempt {attempts}/{max_attempts})")
                    time.sleep(sleep_time)

        batch = gmail_service.new_batch_http_request(callback=batch_callback)
        for msg in messages:
            batch.add(
                gmail_service.users().messages().get(
                    userId='me',
                    id=msg['id'],
                    format='metadata',
                    metadataHeaders=['From', 'Subject']
                ),
                request_id=msg['id']
            )
            batch_requests += 1
            if batch_requests >= 25:
                execute_batch_with_retry(batch)
                time.sleep(1.0)
                batch = gmail_service.new_batch_http_request(callback=batch_callback)
                batch_requests = 0
        if batch_requests > 0:
            execute_batch_with_retry(batch)

        relevant_message_ids = []
        for msg in messages:
            msg_data = message_data_dict.get(msg['id'], {})
            if 'error' in msg_data:
                opportunities.append({
                    'subject': "No Subject",
                    'online_link': "NOT AVAILABLE",
                    'event_date': "NOT AVAILABLE",
                    'agency': "NOT AVAILABLE",
                    'reference': "NOT AVAILABLE",
                    'contact': "NOT AVAILABLE",
                    'raw_subject': "No Subject",
                    'extraction_error': msg_data['error']
                })
                continue

            headers = msg_data.get('payload', {}).get('headers', [])
            if is_google_service_email(headers):
                google_service_count += 1
                continue
            if is_daily_bids_alert_email(headers):
                daily_bids_count += 1
                continue
            relevant_message_ids.append(msg['id'])

        batch = gmail_service.new_batch_http_request(callback=batch_callback)
        batch_requests = 0
        message_data_dict.clear()

        for i, msg_id in enumerate(relevant_message_ids, 1):
            batch.add(
                gmail_service.users().messages().get(
                    userId='me',
                    id=msg_id,
                    format='full'
                ),
                request_id=msg_id
            )
            batch_requests += 1
            if batch_requests >= 25:
                execute_batch_with_retry(batch)
                time.sleep(1.0)
                batch = gmail_service.new_batch_http_request(callback=batch_callback)
                batch_requests = 0
        if batch_requests > 0:
            execute_batch_with_retry(batch)

        for i, msg_id in enumerate(relevant_message_ids, 1):
            msg_data = message_data_dict.get(msg_id, {})
            if 'error' in msg_data:
                opportunities.append({
                    'subject': "No Subject",
                    'online_link': "NOT AVAILABLE",
                    'event_date': "NOT AVAILABLE",
                    'agency': "NOT AVAILABLE",
                    'reference': "NOT AVAILABLE",
                    'contact': "NOT AVAILABLE",
                    'raw_subject': "No Subject",
                    'extraction_error': msg_data['error']
                })
                continue

            headers = msg_data.get('payload', {}).get('headers', [])
            raw_subject = "No Subject"
            for header in headers:
                if header['name'].lower() == 'subject':
                    decoded = email.header.decode_header(header['value'])
                    subject_parts = []
                    for part, encoding in decoded:
                        if isinstance(part, bytes):
                            encoding = encoding or 'utf-8'
                            try:
                                subject_parts.append(part.decode(encoding))
                            except (UnicodeDecodeError, LookupError):
                                subject_parts.append(part.decode('utf-8', errors='replace'))
                            else:
                                subject_parts.append(part)
                    raw_subject = ''.join(subject_parts)
                    break

            body = get_email_body(msg_data.get('payload', {}))

            if raw_subject == "New RfP mail":
                details = process_new_rfp_mail(raw_subject, body)
            else:
                if raw_subject == "New RfP From Bid Mail" and body in ["No body content available.", ""]:
                    details = process_no_body_rfp_email(raw_subject)
                else:
                    details = extract_fields(body, raw_subject)

                if details['subject'] == "No Subject" and details.get('title'):
                    raw_subject = f"{details.get('title', 'Opportunity Details')}"

                online_link = details['online_link']
                if details['subject'] == "No Subject" and online_link != "NOT AVAILABLE":
                    if any(link in online_link for link in [
                        "sam.gov",
                        "dibbs.bsm.dla.mil",
                        "passport.cityofnewyork.us"
                    ]):
                        details['subject'] = clean_subject(raw_subject, body)

                if details['online_link'] == "NOT AVAILABLE" and details['reference'] == "NOT AVAILABLE":
                    data_skip_count += 1
                    details['extraction_error'] = "Skipped: Missing both online link and reference"
                    opportunities.append({
                        'subject': details['subject'],
                        'online_link': details['online_link'],
                        'event_date': details['event_date'],
                        'agency': details['agency'],
                        'reference': details['reference'],
                        'contact': details['contact'],
                        'raw_subject': raw_subject,
                        'extraction_error': details['extraction_error']
                    })
                    continue

                if online_link != "NOT AVAILABLE":
                    if details['reference'] != "NOT AVAILABLE":
                        link_ref_pair = (online_link, details['reference'])
                    else:
                        link_ref_pair = (online_link, details['event_date'])
                    
                    if link_ref_pair in seen_link_ref_pairs:
                        dedup_skip_count += 1
                        details['extraction_error'] = "Duplicate Opportunity (based on link and reference or due date)"
                        opportunities.append({
                            'subject': details['subject'],
                            'online_link': details['online_link'],
                            'event_date': details['event_date'],
                            'agency': details['agency'],
                            'reference': details['reference'],
                            'contact': details['contact'],
                            'raw_subject': raw_subject,
                            'extraction_error': details['extraction_error']
                        })
                        continue
                    seen_link_ref_pairs.add(link_ref_pair)

                if all(details[field] == "NOT AVAILABLE" for field in ['online_link', 'event_date', 'agency', 'reference', 'contact']):
                    data_skip_count += 1
                    details['extraction_error'] = "No meaningful data extracted"
                    opportunities.append({
                        'subject': details['subject'],
                        'online_link': details['online_link'],
                        'event_date': details['event_date'],
                        'agency': details['agency'],
                        'reference': details['reference'],
                        'contact': details['contact'],
                        'raw_subject': raw_subject,
                        'extraction_error': details['extraction_error']
                    })
                    continue

                opportunity_key = (
                    details['online_link'],
                    details['reference'],
                    details['event_date'],
                    details['agency']
                )
                if opportunity_key in seen_opportunities:
                    dedup_skip_count += 1
                    details['extraction_error'] = "Duplicate opportunity"
                else:
                    seen_opportunities.add(opportunity_key)

                opportunities.append({
                    'subject': details['subject'],
                    'online_link': details['online_link'],
                    'event_date': details['event_date'],
                    'agency': details['agency'],
                    'reference': details['reference'],
                    'contact': details['contact'],
                    'raw_subject': raw_subject,
                    'extraction_error': details['extraction_error']
                })

        if opportunities:
            save_opportunities(opportunities, email_ids)

        conn = get_db_connection()
        try:
            cursor = conn.cursor()
            cursor.execute('SELECT subject, online_link, event_date, agency, reference, contact, raw_subject, extraction_error FROM opportunities')
            db_opportunities = [
                {
                    'subject': row[0],
                    'online_link': row[1],
                    'event_date': row[2],
                    'agency': row[3],
                    'reference': row[4],
                    'contact': row[5],
                    'raw_subject': row[6],
                    'extraction_error': row[7]
                } for row in cursor.fetchall()
            ]
        except mysql.connector.Error as e:
            logging.error(f"Failed to fetch opportunities from MySQL: {e}")
            return {"error": f"Failed to fetch opportunities from MySQL: {e}"}
        finally:
            cursor.close()
            conn.close()

        current_date = get_current_date_from_calendar(calendar_service)
        active_events, expired_events, unparsed_events = categorize_events(db_opportunities, current_date)

        active_events = deduplicate_events(active_events, unparsed_events)
        expired_events = deduplicate_events(expired_events, unparsed_events)

        return {
            "total_emails": len(messages) + len(processed_ids),
            "google_service_count": google_service_count,
            "daily_bids_count": daily_bids_count,
            "skipped_count": api_error_count + dedup_skip_count + data_skip_count,
            "opportunities_count": len(db_opportunities),
            "active_events": active_events,
            "expired_events": expired_events,
            "unparsed_events": unparsed_events,
            "timezone": "America/New_York",
            "error": None
        }

    except HttpError as error:
        logging.error(f"Error in list_all_emails: {error}")
        return {"error": f"Gmail API error: {error}"}
    except Exception as e:
        logging.error(f"Unexpected error in list_all_emails: {e}")
        return {"error": f"Unexpected error: {e}"}

def get_current_date_from_calendar(calendar_service: build) -> datetime:
    """Gets the current date from Google Calendar, normalized to midnight."""
    ny_tz = pytz.timezone('America/New_York')
    now = datetime.now(ny_tz)
    return ny_tz.localize(datetime(now.year, now.month, now.day, 0, 0, 0))

def get_email_body(payload: dict) -> str:
    """Extracts the email body content."""
    if 'parts' in payload:
        for part in payload['parts']:
            if part['mimeType'] in ['text/plain', 'text/html']:
                return base64.urlsafe_b64decode(part['body']['data']).decode('utf-8', errors="ignore")
            body = get_email_body(part)
            if body:
                return body
    if 'body' in payload and 'data' in payload['body']:
        return base64.urlsafe_b64decode(payload['body']['data']).decode('utf-8', errors="ignore")
    return "No body content available."

def clean_subject(subject: str, body: str) -> str:
    """Clean subject line, removing unwanted prefixes and date info."""
    prefixes = ['Fwd:', 'FW:', 'RE:']
    for prefix in prefixes:
        subject = re.sub(f'^{prefix}\\s*', '', subject, flags=re.IGNORECASE)
    subject = re.sub(r'\bdue\b\s*[-:]\s*(\d{1,2}/\d{1,2}/\d{4}|[A-Za-z]{3}\s+\d{1,2},\s+\d{4}|.*\d{4}).*$',
                     '', subject, flags=re.IGNORECASE)
    date_patterns = [
        r'\b\d{1,2}/\d{1,2}/\d{4}\b',
        r'\b[A-Za-z]{3},\s+[A-Za-z]{3}\s+\d{1,2}(?:st|nd|rd|th)?\s+\d{4},\s+\d{02}:\d{02}\b',
        r'\b\d{4}-\d{2}-\d{2}\b'
    ]
    for pattern in date_patterns:
        subject = re.sub(pattern, '', subject, flags=re.IGNORECASE)
    subject = re.sub(r'\s+', ' ', subject).strip()
    subject = re.sub(r'[.,;:!?-]+$', '', subject)
    if not subject or subject == "No Subject":
        if body and body != "No body content available.":
            lines = body.split('\n')
            for line in lines[:5]:
                line = line.strip()
                if line and len(line) > 5 and not line.startswith(('http', 'Agency', 'Reference', 'Contact', 'Due')):
                    return re.sub(r'\s+', ' ', line)[:50]
        return "Untitled Opportunity"
    return subject if subject else "Untitled Opportunity"

def is_google_service_email(headers: List[Dict[str, str]]) -> bool:
    """Check if email is from Google services."""
    google_domains = [
        'google.com',
        'googleapis.com',
        'gmail.com',
        'accounts.google.com',
        'mail.google.com'
    ]
    google_subject_keywords = [
        'Google Account',
        'Gmail',
        'Google Security',
        'Google Workspace',
        'Google Cloud'
    ]
    from_header = next((h['value'] for h in headers if h['name'] == 'From'), '')
    if any(domain in from_header for domain in google_domains):
        return True
    subject = next((h['value'] for h in headers if h['name'] == 'Subject'), '').lower()
    if any(keyword.lower() in subject for keyword in google_subject_keywords):
        return True
    return False

def is_daily_bids_alert_email(headers: List[Dict[str, str]]) -> bool:
    """Check if email is a Daily or Weekly Bids Alert."""
    subject = next((h['value'] for h in headers if h['name'] == 'Subject'), '').lower()
    bids_patterns = [
        r'\bdaily\s*bids?\s*alert\b',
        r'\bweekly\s*bids?\s*alert\b',
        r'\bbids?\s*alert\b',
        r'\bbid\s*digest\b',
        r'\bbid\s*summary\b',
        r'\bbid\s*notification\b'
    ]
    return any(re.search(pattern, subject, re.IGNORECASE) for pattern in bids_patterns)

def extract_fields(body: str, subject: str) -> Dict[str, str]:
    """Extracts and cleans all relevant fields from email content."""
    result = {
        'online_link': "NOT AVAILABLE",
        'event_date': "NOT AVAILABLE",
        'agency': "NOT AVAILABLE",
        'reference': "NOT AVAILABLE",
        'contact': "NOT AVAILABLE",
        'extraction_error': None,
        'subject': clean_subject(subject, body)
    }
    is_forwarded = subject.lower().startswith(('fwd:', 'fw:'))
    if is_forwarded:
        result['event_date'] = extract_due_date_from_subject(subject)
    if body not in ["No body content available.", ""]:
        body = re.sub(r'<[^>]+>', '', body)
        body = re.sub(r'\s+', ' ', body).strip()
        result['online_link'] = extract_url_from_body(body)
        if result['event_date'] == "NOT AVAILABLE":
            date_patterns = [
                r'(\w{3}, \w{3} \d{1,2}(?:st|nd|rd|th)? \d{4}, \d{02}:\d{02})',
                r'(\w{3} \d{1,2}, \d{4} at \d{1,2}:\d{02} [AP]M)',
                r'(\d{1,2}/\d{1,2}/\d{4} \d{1,2}:\d{02})',
                r'DUE\s*-\s*(\w{3}, \w{3} \d{1,2}, \d{4})',
                r'due\s*-\s*(\w{3}, \w{3} \d{1,2}, \d{4})',
                r'(\w{3}\s+\d{1,2}, \d{4}\s+at\s+\d{1,2}:\d{02}\s*[AP]M)',
                r'(\d{1,2}/\d{1,2}/\d{4}\s+\d{1,2}:\d{02}(?::\d{02})?\s*[AP]M)'
            ]
            for pattern in date_patterns:
                match = re.search(pattern, body, re.IGNORECASE)
                if match:
                    result['event_date'] = format_extracted_date(match.group(1))
                    break
    else:
        result['event_date'] = extract_due_date_from_subject(subject)
    ref_contact = extract_reference_and_contact(body, subject)
    result['reference'] = ref_contact['reference']
    result['contact'] = ref_contact['contact']
    result['agency'] = ref_contact['agency'] if ref_contact['agency'] != "NOT AVAILABLE" else clean_agency_name("", subject)
    return result

def extract_due_date_from_subject(subject: str) -> str:
    """Enhanced date extraction with comprehensive pattern matching."""
    subject = subject.strip()
    patterns = [
        r'(?:DUE|due|Due)[\s:-]*(?:date\s+is|date:?)[\s-]*([A-Za-z]{3},\s*[A-Za-z]{3}\s+\d{1,2}(?:st|nd|rd|th)?\s+\d{4},\s*\d{02}:\d{02})',
        r'(?:DUE|due|Due)[\s:-]*(?:date|date:)[\s-]*(\d{1,2}/\d{1,2}/\d{4}\s+\d{1,2}:\d{02}(?::\d{02})?\s*[AP]M)',
        r'(?:DUE|due|Due)[\s:-]*(?:date|date:)?[\s-]*([A-Za-z]{3}\s+\d{1,2}(?:st|nd|rd|th)?\s+\d{4})',
        r'(?:DUE|due|Due)[\s:-]*(?:date|date:)?[\s-]*(\d{1,2}\s+[A-Za-z]{3}\s+\d{4})',
        r'(?:DUE|due|Due)[\s:-]*(?:date|date:)?[\s-]*([A-Za-z]{3},\s*[A-Za-z]{3}\s+\d{1,2}(?:st|nd|rd|th)?\s+\d{4})',
        r'(?:DUE|due|Due)\s*[-:]\s*([A-Za-z]{3}\s+\d{1,2},\s+\d{4})',
        r'(?:DUE|due|Due)\s*[-:]\s*(\d{1,2}\s+[A-Za-z]{3}\s+\d{4})',
        r'(?:DUE|due|Due)\s*[-:]\s*(\d{1,2}/\d{1,2}/\d{4})',
        r'\b(?:closing|submit|deadline|due)\s*(?:date|by)?\s*[-:]\s*([A-Za-z]{3}\s+\d{1,2},\s+\d{4})',
        r'\b(?:closing|submit|deadline|due)\s*(?:date|by)?\s*[-:]\s*(\d{1,2}\s+[A-Za-z]{3}\s+\d{4})',
        r'\b(?:closing|submit|deadline|due)\s*(?:date|by)?\s*[-:]\s*(\d{1,2}/\d{1,2}/\d{4})',
        r'\b([A-Za-z]{3},\s+[A-Za-z]{3}\s+\d{1,2}\s+\d{4},\s+\d{02}:\d{02})\b',
        r'\b([A-Za-z]{3}\s+\d{1,2},\s+\d{4}\s+at\s+\d{1,2}:\d{02}\s*[AP]M)\b',
        r'\b([A-Za-z]{3}\s+\d{1,2},\s+\d{4})\b',
        r'\b(\d{1,2}\s+[A-Za-z]{3}\s+\d{4})\b',
        r'\b(\d{1,2}/\d{1,2}/\d{4})\b',
    ]
    for pattern in patterns:
        match = re.search(pattern, subject, re.IGNORECASE)
        if match:
            date_str = match.group(1)
            date_str = re.sub(r'(st|nd|rd|th)', '', date_str)
            date_str = re.sub(r'^u\s*,', '', date_str, flags=re.IGNORECASE)
            date_str = re.sub(r'\s+', ' ', date_str).strip()
            formatted_date = format_extracted_date(date_str)
            if formatted_date != "NOT AVAILABLE":
                return formatted_date
    return "NOT AVAILABLE"

def format_extracted_date(date_str: str) -> str:
    """Formats extracted date string into standard format."""
    logging.debug(f"Attempting to parse date: {date_str}")
    try:
        date_str = re.sub(r'[^\w\s/:,-]', '', date_str)
        date_str = re.sub(r'\s+', ' ', date_str).strip()
        date_str = re.sub(r'(st|nd|rd|th)', '', date_str, flags=re.IGNORECASE)
        date_str = re.sub(r'^u\s*,', '', date_str, flags=re.IGNORECASE)
        dt = parse_date(date_str, fuzzy=True)
        return dt.strftime('%a, %b %d %Y, %H:%M')
    except Exception as e:
        logging.error(f"Failed to parse date: {date_str}, error: {str(e)}")
        return "NOT AVAILABLE"

def extract_url_from_body(body: str) -> str:
    """Extracts URL from body excluding govdirections URLs."""
    if body == "No body content available.":
        return "NOT AVAILABLE"
    url_pattern = r'(https?://[^\s\'">]+)'
    matches = re.findall(url_pattern, body, re.IGNORECASE)
    for url in matches:
        url = url.strip()
        url = re.sub(r'[.,;:!?)\]\s]+$', '', url)
        url = re.sub(r'Event$', '', url, flags=re.IGNORECASE)
        if 'govdirections' not in url.lower() and re.match(r'^https?://[^\s/$.?#].[^\s]*$', url):
            return url
    return "NOT AVAILABLE"

def extract_reference_and_contact(body: str, subject: str) -> Dict[str, str]:
    """Extracts reference, contact, and agency from body and subject."""
    result = {
        'reference': extract_reference_from_subject(subject),
        'contact': "NOT AVAILABLE",
        'agency': "NOT AVAILABLE"
    }
    if body not in ["No body content available.", ""]:
        block_match = re.search(
            r'The agency sponsor is:\s*(.*?)?\s*The reference for this notice \(if available\):\s*(.*?)\s*Agency Contact Information:\s*(.*?)(?:\n|$)',
            body,
            re.IGNORECASE | re.DOTALL
        )
        if block_match:
            agency = block_match.group(1).strip()
            if agency:
                result['agency'] = clean_agency_name(agency, subject)
            reference = block_match.group(2).strip()
            if reference and is_valid_reference(reference):
                result['reference'] = reference
            contact = block_match.group(3).strip()
            phone_match = re.search(r'(\d{3}-\d{3}-\d{4})', contact)
            if phone_match:
                digits = re.sub(r'\D', '', phone_match.group(1))
                if len(digits) == 10:
                    result['contact'] = f"{digits[:3]}-{digits[3:6]}-{digits[6:]}"
        if result['contact'] == "NOT AVAILABLE":
            phone_match = re.search(r'Agency Contact Information:\s*(\d{3}-\d{3}-\d{4})', body, re.IGNORECASE)
            if phone_match:
                digits = re.sub(r'\D', '', phone_match.group(1))
                if len(digits) == 10:
                    result['contact'] = f"{digits[:3]}-{digits[3:6]}-{digits[6:]}"
    return result

def clean_agency_name(agency_text: str, subject: str) -> str:
    """Cleans agency names with fallback to subject extraction."""
    if agency_text:
        agency_text = re.split(r'(?:\bthe\b|\breference\b|\bnotice\b|\bcontact\b|\brfp\b|\bbid\b|\bsolicitation\b)',
                              agency_text, flags=re.IGNORECASE)[0]
        agency_text = re.sub(r'[^a-zA-Z0-9\s,&-]+$', '', agency_text).strip()
        agency_text = re.sub(r'\d{3}-\d{3}-\d{4}', '', agency_text).strip()
        if agency_text:
            return agency_text[:40] + ("..." if len(agency_text) > 40 else "")
    agency = re.sub(r'^(Fwd:\s*|RE:\s*|RFP\s*|Bid\s*|Solicitation\s*)', '', subject, flags=re.IGNORECASE)
    agency = re.sub(r'-\s*due\s*.*$', '', agency, flags=re.IGNORECASE).strip()
    return agency[:40] + ("..." if len(agency) > 40 else "") if agency else "NOT AVAILABLE"

def extract_reference_from_subject(subject: str) -> str:
    """Extracts reference number from email subject."""
    ref_patterns = [
        r'RFP\s*#?([A-Z0-9-]{3,50})\b',
        r'Bid\s*#?([A-Z0-9-]{3,50})\b',
        r'Solicitation\s*#?([A-Z0-9-]{3,50})\b',
        r'Ref\s*#?([A-Z0-9-]{3,50})\b',
        r'#([A-Z0-9-]{3,50})\b',
        r'\b([A-Z]{2,5}\d{3,8}-?\d{0,5})\b'
    ]
    for pattern in ref_patterns:
        match = re.search(pattern, subject, re.IGNORECASE)
        if match and is_valid_reference(match.group(1)):
            return match.group(1).upper()
    return "NOT AVAILABLE"

def is_valid_reference(ref: str) -> bool:
    """Validate if extracted reference meets requirements."""
    if not ref or not isinstance(ref, str) or ref.upper() == "NOT AVAILABLE":
        return False
    invalid_patterns = [
        r'Agency-Contact-Information',
        r'Learn-to-Do-Business',
        r'Summary-Information',
        r'Competitive-Intelligence',
        r'Regrds----Rashi',
        r'\d{3}-\d{3}-\d{4}',
        r'^https?://',
        r'^www\.',
        r'^event',
        r'^view',
        r'^s/'
    ]
    for pattern in invalid_patterns:
        if re.search(pattern, ref, re.IGNORECASE):
            return False
    if len(ref) <= 5 and ref.isupper() and ref.isalpha():
        return False
    return bool(
        3 <= len(ref) <= 50 and
        not ref.startswith(('http', 'www', 'event', 'view', 's/')) and
        any(char.isalnum() for char in ref)
    )

def categorize_events(opportunities: List[Dict], current_date: datetime) -> Tuple[List, List, List]:
    """Categorizes events into active, expired, and unparsed tables."""
    active_events = []
    expired_events = []
    unparsed_events = []
    ny_tz = pytz.timezone('America/New_York')
    for event in opportunities:
        event_date_str = event.get('event_date', "NOT AVAILABLE")
        error = event.get('extraction_error')
        if error or event_date_str == "NOT AVAILABLE":
            unparsed_events.append({
                **event,
                'reason': error or "No valid date extracted"
            })
            continue
        try:
            formats = [
                '%a, %b %d %Y, %H:%M',
                '%b %d %Y, %I:%M %p',
                '%a, %b %d %Y',
                '%b %d, %Y',
                '%m/%d/%Y',
                '%d %b %Y',
                '%Y-%m-%d'
            ]
            event_date = None
            for fmt in formats:
                try:
                    event_date = datetime.strptime(event_date_str, fmt)
                    logging.debug(f"Parsed date {event_date_str} with format {fmt}")
                    break
                except ValueError:
                    continue
            if event_date is None:
                event_date = parse_date(event_date_str, fuzzy=True)
                logging.debug(f"Parsed date {event_date_str} with dateutil.parser")
            event_date = ny_tz.localize(event_date)
            days_difference = (event_date - current_date).days
            if days_difference >= 0:
                active_events.append({
                    **event,
                    'days_to_expire': days_difference,
                    'formatted_date': event_date.strftime('%Y-%m-%d')
                })
            elif days_difference < 0 and abs(days_difference) <= 90:
                expired_events.append({
                    **event,
                    'days_expired': abs(days_difference),
                    'formatted_date': event_date.strftime('%Y-%m-%d')
                })
            else:
                unparsed_events.append({
                    **event,
                    'reason': "Date too far in the past"
                })
        except ValueError as e:
            unparsed_events.append({
                **event,
                'reason': f"Date parsing failed: {str(e)} (input: {event_date_str})"
            })
            logging.error(f"Failed to parse date in categorize_events: {event_date_str}, error: {str(e)}")
    active_events.sort(key=lambda x: x.get('days_to_expire', 0))
    expired_events.sort(key=lambda x: x.get('days_expired', 0))
    return active_events, expired_events, unparsed_events

def display_events_table(events: List[Dict], title: str, is_active: bool = True) -> str:
    """Generates an HTML table for events, with optional console output."""
    if not events:
        return f"<h2 class='text-xl font-bold mt-4'>{title} (No entries found)</h2>"

    table_data = []
    for event in events:
        table_data.append([
            event['subject'][:50] + "..." if len(event['subject']) > 50 else event['subject'],
            event['online_link'],
            event.get('formatted_date', event['event_date']),
            event['agency'],
            event['reference'],
            event['contact']
        ])

    headers = [
        "Opportunity Title",
        "Document Link",
        "Due Date",
        "Agency",
        "Reference",
        "Contact"
    ]

    # Console output (optional, retained for debugging)
    print(f"\n{title} ({len(events)} found):")
    print(tabulate(
        table_data,
        headers=headers,
        tablefmt="grid",
        maxcolwidths=[50, None, 25, 40, 20, 15],
        stralign="left"
    ))

    # HTML output for web interface
    html = f"<h2 class='text-xl font-bold mt-4'>{title} ({len(events)} found)</h2>"
    html += "<div class='overflow-x-auto'>"
    html += "<table class='min-w-full bg-white border border-gray-300 table-fixed'>"
    html += "<thead><tr>"
    for header in headers:
        html += f"<th class='py-2 px-4 border-b text-left whitespace-nowrap'>{header}</th>"
    html += "</tr></thead><tbody>"

    for row in table_data:
        # Prepare data attributes for modal
        data_attrs = (
            f"data-subject='{row[0]}' "
            f"data-link='{row[1] if row[1] else 'NOT AVAILABLE'}' "
            f"data-date='{row[2] if row[2] else 'NOT AVAILABLE'}' "
            f"data-agency='{row[3] if row[3] else 'NOT AVAILABLE'}' "
            f"data-reference='{row[4] if row[4] else 'NOT AVAILABLE'}' "
            f"data-contact='{row[5] if row[5] else 'NOT AVAILABLE'}'"
        )
        html += f"<tr class='cursor-pointer hover:bg-gray-100' onclick='showRfpModal(this, event)' {data_attrs}>"
        for i, cell in enumerate(row):
            cell = cell if cell else "N/A"
            if i == 1 and cell.startswith('http'):  # Document Link column
                cell = (
                    f"<a href='{cell}' class='text-blue-500 hover:underline' target='_blank' data-no-modal>"
                    f"{cell[:30]}..."
                    f"</a>"
                )
            elif i == 2:  # Due Date column
                cell = f"<span class='whitespace-nowrap'>{cell}</span>"
            elif i == 5:  # Contact column
                cell = f"<span class='whitespace-nowrap'>{cell}</span>"
            html += f"<td class='py-2 px-4 border-b'>{cell}</td>"
        html += "</tr>"

    html += "</tbody></table>"
    html += "</div>"
    return html

def process_no_body_rfp_email(subject: str) -> Dict[str, str]:
    """Processes emails with subject 'New RfP From Bid Mail' and no body."""
    cleaned_subject = clean_subject(subject, "No body content available.")
    subject_display = cleaned_subject[:50] + "..." if len(cleaned_subject) > 50 else cleaned_subject
    result = {
        'subject': subject_display,
        'online_link': "NOT AVAILABLE",
        'event_date': "NOT AVAILABLE",
        'agency': "NOT AVAILABLE",
        'reference': "NOT AVAILABLE",
        'contact': "NOT AVAILABLE",
        'raw_subject': subject,
        'extraction_error': None
    }
    result['event_date'] = extract_due_date_from_subject(cleaned_subject)
    result['reference'] = extract_reference_from_subject(cleaned_subject)
    result['agency'] = clean_agency_name("", cleaned_subject)
    phone_match = re.search(r'(\d{3}-\d{3}-\d{4})', cleaned_subject)
    if phone_match:
        digits = re.sub(r'\D', '', phone_match.group(1))
        if len(digits) == 10:
            result['contact'] = f"{digits[:3]}-{digits[3:6]}-{digits[6:]}"
    url_match = re.search(r'(https?://[^\s\'">]+)', cleaned_subject)
    if url_match:
        url = url_match.group(0).strip()
        url = re.sub(r'[.,;:!?)\]\s]+$', '', url)
        if 'govdirections' not in url.lower() and re.match(r'^https?://[^\s/$.?#].[^\s]*$', url):
            result['online_link'] = url
    if all(value == "NOT AVAILABLE" for value in [result['event_date'], result['agency'], result['reference']]):
        result['extraction_error'] = "No meaningful data extracted from subject"
    return result

def process_new_rfp_mail(subject: str, body: str) -> Dict[str, str]:
    """Processes emails with subject 'New RfP mail'."""
    result = {
        'subject': clean_subject(subject, body),
        'online_link': "NOT AVAILABLE",
        'event_date': "NOT AVAILABLE",
        'agency': "NOT AVAILABLE",
        'reference': "NOT AVAILABLE",
        'contact': "NOT AVAILABLE",
        'raw_subject': subject,
        'extraction_error': None
    }
    if body in ["No body content available.", ""]:
        result['extraction_error'] = "No body content available"
        return result
    body = re.sub(r'<[^>]+>', '', body)
    body = re.sub(r'\s+', ' ', body).strip()
    table_pattern = r'Subject \(50 chars max\)\s*\|([^\|]*)\|\s*Online Link\s*\|([^\|]*)\|\s*Event Date\s*\|([^\|]*)\|\s*Agency\s*\|([^\|]*)\|\s*Reference\s*\|([^\|]*)\|\s*Contact\s*\|([^\|]*)\|'
    table_match = re.search(table_pattern, body, re.IGNORECASE)
    if table_match:
        result['subject'] = table_match.group(1).strip()[:50]
        result['online_link'] = table_match.group(2).strip()
        result['event_date'] = format_extracted_date(table_match.group(3).strip())
        result['agency'] = table_match.group(4).strip()[:40]
        result['reference'] = table_match.group(5).strip()
        result['contact'] = table_match.group(6).strip()
        if result['online_link'] and not re.match(r'^https?://[^\s/$.?#].[^\s]*$', result['online_link']):
            result['online_link'] = "NOT AVAILABLE"
        if result['contact'] and not re.match(r'\d{3}-\d{3}-\d{4}', result['contact']):
            result['contact'] = "NOT AVAILABLE"
        if result['reference'] and not is_valid_reference(result['reference']):
            result['reference'] = "NOT AVAILABLE"
        if not result['agency']:
            result['agency'] = clean_agency_name("", subject)
    else:
        result['online_link'] = extract_url_from_body(body)
        date_patterns = [
            r'(\w{3}, \w{3} \d{1,2}(?:st|nd|rd|th)? \d{4}, \d{02}:\d{02})',
            r'(\w{3} \d{1,2}, \d{4} at \d{1,2}:\d{02} [AP]M)',
            r'(\d{1,2}/\d{1,2}/\d{4} \d{1,2}:\d{02})',
            r'DUE\s*-\s*(\w{3}, \w{3} \d{1,2}, \d{4})',
            r'due\s*-\s*(\w{3}, \w{3} \d{1,2}, \d{4})',
            r'(\w{3}\s+\d{1,2}, \d{4}\s+at\s+\d{1,2}:\d{02}\s*[AP]M)',
            r'(\d{1,2}/\d{1,2}/\d{4}\s+\d{1,2}:\d{02}(?::\d{02})?\s*[AP]M)'
        ]
        for pattern in date_patterns:
            match = re.search(pattern, body, re.IGNORECASE)
            if match:
                result['event_date'] = format_extracted_date(match.group(1))
                break
        ref_contact = extract_reference_and_contact(body, subject)
        result['reference'] = ref_contact['reference']
        result['contact'] = ref_contact['contact']
        result['agency'] = ref_contact['agency'] if ref_contact['agency'] != "NOT AVAILABLE" else clean_agency_name("", subject)
        result['extraction_error'] = "No table found, used fallback extraction"
    if all(value == "NOT AVAILABLE" for value in [result['online_link'], result['event_date'], result['agency'], result['reference'], result['contact']]):
        result['extraction_error'] = "No meaningful data extracted"
    return result

@app.route('/')
def index():
    logging.debug("Serving index route")
    if 'username' in session:
        return redirect(url_for('dashboard'))
    return render_template('login.html')

@app.route('/login', methods=['POST'])
def login():
    logging.debug("Processing login request")
    username = request.form.get('username')
    password = request.form.get('password')
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('SELECT password, is_admin FROM users WHERE username = %s', (username,))
        user = cursor.fetchone()
        if user and user[0] == password:
            session['username'] = username
            session['is_admin'] = user[1]
            logging.debug(f"User {username} logged in successfully")
            return redirect(url_for('dashboard'))
        flash('Invalid credentials, please try again.')
        logging.warning(f"Failed login attempt for username: {username}")
        return redirect(url_for('index'))
    except mysql.connector.Error as e:
        logging.error(f"Database error during login: {e}")
        flash(f"Database error: {e}")
        return redirect(url_for('index'))
    finally:
        if conn.is_connected():
            cursor.close()
            conn.close()

@app.route('/dashboard')
def dashboard():
    logging.debug("Serving dashboard route")
    if 'username' not in session:
        logging.warning("Unauthorized access attempt to dashboard")
        return redirect(url_for('index'))

    try:
        logging.info("Attempting Google API authentication")
        init_database()
        gmail_service, calendar_service = authenticate_google()
        logging.info("Fetching and processing emails")
        result = list_all_emails(gmail_service, calendar_service)

        if result.get("error"):
            logging.error(f"Email processing error: {result['error']}")
            flash(result["error"])
            return render_template('dashboard.html', username=session['username'], error=result["error"])

        logging.info(f"Processed {result['total_emails']} emails, {result['opportunities_count']} opportunities")
        active_table = display_events_table(result["active_events"], "Active RFP Opportunities", True)
        expired_table = display_events_table(result["expired_events"], "Recently Expired RFPs (Last 90 days)", False)
        unparsed_table = display_events_table(result["unparsed_events"], "RFPs with Missing or Unparsed Dates", False)

        return render_template(
            'dashboard.html',
            username=session['username'],
            total_emails=result["total_emails"],
            google_service_count=result["google_service_count"],
            daily_bids_count=result["daily_bids_count"],
            skipped_count=result["skipped_count"],
            opportunities_count=result["opportunities_count"],
            timezone=result["timezone"],
            active_table=active_table,
            expired_table=expired_table,
            unparsed_table=unparsed_table
        )

    except FileNotFoundError as e:
        logging.error(f"Authentication error: {e}")
        flash("Authentication failed: Missing client.json file.")
        return render_template('dashboard.html', username=session['username'], error=str(e))
    except mysql.connector.Error as e:
        logging.error(f"Database error: {e}")
        flash(f"Database error: {e}")
        return render_template('dashboard.html', username=session['username'], error=str(e))
    except Exception as e:
        logging.error(f"Dashboard error: {e}")
        flash(f"Error processing emails: {e}")
        return render_template('dashboard.html', username=session['username'], error=str(e))

@app.route('/user_management')
def user_management():
    if 'username' not in session or not session.get('is_admin'):
        flash('Unauthorized access.')
        logging.warning(f"Unauthorized access attempt to user_management by {session.get('username')}")
        return redirect(url_for('dashboard'))
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('SELECT username, is_admin FROM users')
        users = [{'username': row[0], 'is_admin': row[1]} for row in cursor.fetchall()]
        return render_template('user_management.html', username=session['username'], users=users)
    except mysql.connector.Error as e:
        logging.error(f"Database error in user_management: {e}")
        flash(f"Database error: {e}")
        return redirect(url_for('dashboard'))
    finally:
        if conn.is_connected():
            cursor.close()
            conn.close()

@app.route('/add_user', methods=['POST'])
def add_user():
    if 'username' not in session or not session.get('is_admin'):
        flash('Unauthorized access.')
        return redirect(url_for('dashboard'))
    username = request.form.get('username')
    password = request.form.get('password')
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('INSERT INTO users (username, password, is_admin) VALUES (%s, %s, %s)',
                       (username, password, False))
        conn.commit()
        flash(f'User {username} added successfully.')
        logging.info(f"User {username} added by {session['username']}")
        return redirect(url_for('user_management'))
    except mysql.connector.Error as e:
        logging.error(f"Database error in add_user: {e}")
        flash(f"Database error: {e}")
        return redirect(url_for('user_management'))
    finally:
        if conn.is_connected():
            cursor.close()
            conn.close()

@app.route('/toggle_admin/<username>', methods=['POST'])
def toggle_admin(username):
    if 'username' not in session or not session.get('is_admin'):
        flash('Unauthorized access.')
        return redirect(url_for('dashboard'))
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('SELECT is_admin FROM users WHERE username = %s', (username,))
        current_status = cursor.fetchone()[0]
        new_status = not current_status
        cursor.execute('UPDATE users SET is_admin = %s WHERE username = %s', (new_status, username))
        conn.commit()
        flash(f"User {username} admin status updated to {'Admin' if new_status else 'Non-Admin'}.")
        logging.info(f"User {username} admin status toggled to {new_status} by {session['username']}")
        return redirect(url_for('user_management'))
    except mysql.connector.Error as e:
        logging.error(f"Database error in toggle_admin: {e}")
        flash(f"Database error: {e}")
        return redirect(url_for('user_management'))
    finally:
        if conn.is_connected():
            cursor.close()
            conn.close()

@app.route('/delete_user/<username>', methods=['POST'])
def delete_user(username):
    if 'username' not in session or not session.get('is_admin'):
        flash('Unauthorized access.')
        logging.warning(f"Unauthorized access attempt to delete_user by {session.get('username')}")
        return redirect(url_for('dashboard'))
    
    if username == session['username']:
        flash('You cannot delete your own account.')
        logging.warning(f"User {session['username']} attempted to delete their own account")
        return redirect(url_for('user_management'))
    
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('DELETE FROM users WHERE username = %s', (username,))
        if cursor.rowcount == 0:
            flash(f'User {username} not found.')
            logging.warning(f"Attempted to delete non-existent user {username} by {session['username']}")
        else:
            conn.commit()
            flash(f'User {username} deleted successfully.')
            logging.info(f"User {username} deleted by {session['username']}")
        return redirect(url_for('user_management'))
    except mysql.connector.Error as e:
        logging.error(f"Database error in delete_user: {e}")
        flash(f"Database error: {e}")
        return redirect(url_for('user_management'))
    finally:
        if conn.is_connected():
            cursor.close()
            conn.close()

@app.route('/update_password', methods=['GET', 'POST'])
def update_password():
    if 'username' not in session:
        flash('Please log in to update your password.')
        return redirect(url_for('index'))
    if request.method == 'POST':
        new_password = request.form.get('new_password')
        try:
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute('UPDATE users SET password = %s WHERE username = %s',
                           (new_password, session['username']))
            conn.commit()
            flash('Password updated successfully.')
            logging.info(f"Password updated for user {session['username']}")
            return redirect(url_for('dashboard'))
        except mysql.connector.Error as e:
            logging.error(f"Database error in update_password: {e}")
            flash(f"Database error: {e}")
            return redirect(url_for('update_password'))
        finally:
            if conn.is_connected():
                cursor.close()
                conn.close()
    return render_template('update_password.html', username=session['username'])

@app.route('/logout')
def logout():
    logging.debug(f"Processing logout request for user: {session.get('username')}")
    session.pop('username', None)
    session.pop('is_admin', None)
    flash('You have been logged out.')
    return redirect(url_for('index'))

if __name__ == '__main__':
    logging.debug("Starting Flask server")
    try:
        app.run(debug=True, host='0.0.0.0',port=5000)
    except Exception as e:
        logging.error(f"Failed to start Flask server: {e}")
        print(f"Error starting server: {e}")